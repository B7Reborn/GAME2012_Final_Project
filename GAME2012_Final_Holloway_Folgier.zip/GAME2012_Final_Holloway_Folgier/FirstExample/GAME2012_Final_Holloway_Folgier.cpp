﻿
//////////////////////////////////////////////////////////////////////////////////////////////////////////
//	GAME2012_Final_Holloway_Folgier.cpp by Shane Holloway - 101273911 and Maddison Folgier - 101245691
//	(C) 2020 All Rights Reserved
//	
//	Description: Contains a castle and hedge maze. The maze can be navigated with WASD, use the mouse to
//				move the camera. The exit to the maze is locked, and must be opened by placing a cube
//				onto a pedestal before the player can exit. For debugging purposes, the camera can be
//				moved along the Y-axis using the RF keys.
//////////////////////////////////////////////////////////////////////////////////////////////////////////

#include <string>
using namespace std;

#include <cstdlib>
#include <ctime>
#include "vgl.h"
#include "LoadShaders.h"
#include "Light.h"
#include "Shape.h"
#include "glm\glm.hpp"
#include "glm\gtc\matrix_transform.hpp"
#include <iostream>
#include <vector>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#define FPS 60
#define MOVESPEED 0.1f
#define TURNSPEED 0.05f
#define X_AXIS glm::vec3(1,0,0)
#define Y_AXIS glm::vec3(0,1,0)
#define Z_AXIS glm::vec3(0,0,1)
#define XY_AXIS glm::vec3(1,1,0)
#define YZ_AXIS glm::vec3(0,1,1)
#define XZ_AXIS glm::vec3(1,0,1)


enum keyMasks {
	KEY_FORWARD =  0b00000001,		// 0x01 or 1 or 01
	KEY_BACKWARD = 0b00000010,		// 0x02 or 2 or 02
	KEY_LEFT = 0b00000100,		
	KEY_RIGHT = 0b00001000,
	KEY_UP = 0b00010000,
	KEY_DOWN = 0b00100000,
	KEY_MOUSECLICKED = 0b01000000
	// Any other keys you want to add.
};

// IDs.
GLuint vao, ibo, points_vbo, colors_vbo, uv_vbo, normals_vbo, modelID, viewID, projID;
GLuint program;

// Matrices.
glm::mat4 View, Projection;

// Our bitflags. 1 byte for up to 8 keys.
unsigned char keys = 0; // Initialized to 0 or 0b00000000.

// Camera and transform variables.
float scale = 1.0f, angle = 0.0f;
glm::vec3 position, frontVec, worldUp, upVec, rightVec; // Set by function
GLfloat pitch, yaw;
int lastX, lastY;

// Bonus variables
bool keyCollected = false, keyPlaced = false, winText = false;
float keyHeight = 0.5f;
bool movingUp = true;
float keyAngle = 0.0f;

// Texture variables.
GLuint alexTx, hedgeTx, cobblestoneTx, dirtTx, cobblefloorTx, doorTx, blankTx;
GLint width, height, bitDepth;

// Light variables.
AmbientLight aLight(glm::vec3(1.0f, 1.0f, 1.0f),	// Ambient colour.
	0.15f);							// Ambient strength.

PointLight pLights[33] = {	{ glm::vec3(19.5f, 0.5f, -34.5f), 5.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },		// 1
							{ glm::vec3(21.5f, 0.5f, -34.5f), 5.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },		// 2
							{ glm::vec3(19.5f, 0.5f, -32.5f), 5.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },		// 3
							{ glm::vec3(21.5f, 0.5f, -32.5f), 5.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },		// 4
							{ glm::vec3(13.5f, 0.5f, -21.5f), 10.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },		// 5
							{ glm::vec3(10.5f, 0.5f, -19.5f), 10.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },		// 6
							{ glm::vec3(10.5f, 0.5f, -23.5f), 10.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },		// 7
							{ glm::vec3(16.5f, 0.5f, -23.5f), 10.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },		// 8
							{ glm::vec3(16.5f, 0.5f, -19.5f), 10.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },		// 9
							{ glm::vec3(5.5f, 0.5f, -5.5f), 5.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },			// 10
							{ glm::vec3(17.5, 0.5f, -34.5), 5.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },			// 11
							{ glm::vec3(6.5f, 0.5f, -32.5f), 5.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },		// 12
							{ glm::vec3(6.5f, 0.5f, -27.5f), 5.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },		// 13
							{ glm::vec3(14.5f, 0.5f, -28.5f), 5.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },		// 14
							{ glm::vec3(10.5f, 0.5f, -26.5f), 5.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },		// 15
							{ glm::vec3(13.5f, 0.5f, -32.5f), 5.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },		// 16
							{ glm::vec3(24.5f, 0.5f, -28.5f), 5.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },		// 17
							{ glm::vec3(19.5f, 0.5f, -29.5f), 5.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },		// 18
							{ glm::vec3(19.5f, 0.5f, -23.5f), 5.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },		// 19
							{ glm::vec3(23.5f, 0.5f, -22.5f), 5.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },		// 20
							{ glm::vec3(23.5f, 0.5f, -16.5f), 5.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },		// 21
							{ glm::vec3(21.5f, 0.5f, -18.5f), 5.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },		// 22
							{ glm::vec3(7.5f, 0.5f, -16.5f), 5.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },		// 23
							{ glm::vec3(23.5f, 0.5f, -11.5f), 5.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },		// 24
							{ glm::vec3(23.5f, 0.5f, -8.5f), 15.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },		// 25
							{ glm::vec3(20.5f, 0.5f, -6.5f), 5.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },		// 26
							{ glm::vec3(13.5f, 0.5f, -5.5f), 5.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },		// 27
							{ glm::vec3(12.5f, 0.5f, -9.5f), 5.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },		// 28
							{ glm::vec3(8.5f, 0.5f, -10.5f), 5.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },		// 29
							{ glm::vec3(10.5f, 0.5f, -14.5f), 5.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },		// 30
							{ glm::vec3(10.5f, 0.5f, -7.5f), 5.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },		// 31
							{ glm::vec3(15.5f, 0.5f, -12.5f), 5.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f },		// 32
							{ glm::vec3(24.5f, 0.5f, -24.5f), 5.0f, glm::vec3(1.0f, 1.0f, 1.0f), 1.0f } };		// 33

void timer(int);
void populateVectors(int, int, int, int, float, float);
void drawMaze();


void resetView()
{
	position = glm::vec3(20.5f, 0.6f, -33.5f);
	frontVec = glm::vec3(0.0f, 0.0f, -1.0f);
	worldUp = glm::vec3(0.0f, 1.0f, 0.0f);
	pitch = 0.0f;
	yaw = 90.0f;
	// View will now get set only in transformObject
}

// Shapes. Recommend putting in a map
Cube g_cube(1);
Prism g_pedestal(8);
// Total grid dimensions: 30 x 40
// Columns go left -> right, rows go front -> back
Grid2 g_grid(40, 30, 30, 40);
// Middle room prisms
RectPrism g_roomFloor(11, 7, 11, 7);
RectPrism g_roomWall_1(1, 3, 1, 3);
RectPrism g_roomWall_2(1, 3, 1, 3);
RectPrism g_roomWall_3(1, 3, 1, 3);
RectPrism g_roomWall_4(1, 3, 1, 3);
RectPrism g_roomWall_5(7, 1, 7, 1);
RectPrism g_roomWall_6(7, 1, 7, 1);
// Maze entrance/exit gates
Cube g_gate_1(1);
Cube g_gate_2(1);
Cube g_gatewall_1(1);
Cube g_gatewall_2(1);
Cube g_gatewall_3(1);
Cube g_gatewall_4(1);

// Vectors for maze itself. Rectangular prisms for the hedges are in the first vector, x/z locations for their transform are located in the second vector.
vector<RectPrism> hedgeVec;
vector<float> pointsVec;

void init(void)
{
	srand((unsigned)time(NULL));
	//Specifying the name of vertex and fragment shaders.
	ShaderInfo shaders[] = {
		{ GL_VERTEX_SHADER, "triangles.vert" },
		{ GL_FRAGMENT_SHADER, "triangles.frag" },
		{ GL_NONE, NULL }
	};

	//Loading and compiling shaders
	program = LoadShaders(shaders);
	glUseProgram(program);	//My Pipeline is set up

	modelID = glGetUniformLocation(program, "model");
	projID = glGetUniformLocation(program, "projection");
	viewID = glGetUniformLocation(program, "view");

	// Projection matrix : 45∞ Field of View, aspect ratio, display range : 0.1 unit <-> 100 units
	Projection = glm::perspective(glm::radians(45.0f), 1.0f / 1.0f, 0.1f, 100.0f);

	// Camera matrix
	resetView();

	// Image loading.
	stbi_set_flip_vertically_on_load(true);

	unsigned char* image = stbi_load("alex.jpg", &width, &height, &bitDepth, 0);
	if (!image) cout << "Unable to load file!" << endl;

	glGenTextures(1, &alexTx);
	glBindTexture(GL_TEXTURE_2D, alexTx);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
	// Note: image types with native transparency will need to be GL_RGBA instead of GL_RGB.
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glGenerateMipmap(GL_TEXTURE_2D);
	//glBindTexture(GL_TEXTURE_2D, 0);
	stbi_image_free(image);

	// Second texture. 
	unsigned char* image2 = stbi_load("Hedge.jpg", &width, &height, &bitDepth, 0);
	if (!image) cout << "Unable to load file!" << endl;

	glGenTextures(1, &hedgeTx);
	glBindTexture(GL_TEXTURE_2D, hedgeTx);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image2);
	// Note: image types with native transparency will need to be GL_RGBA instead of GL_RGB.
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glGenerateMipmap(GL_TEXTURE_2D);
	//glBindTexture(GL_TEXTURE_2D, 0);
	stbi_image_free(image2);

	// Third texture. Blank one.
	unsigned char* image3 = stbi_load("blank.jpg", &width, &height, &bitDepth, 0);
	if (!image3) cout << "Unable to load file!" << endl;
	
	glGenTextures(1, &blankTx);
	glBindTexture(GL_TEXTURE_2D, blankTx);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image3);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glGenerateMipmap(GL_TEXTURE_2D);
	//glBindTexture(GL_TEXTURE_2D, 0);
	stbi_image_free(image3);

	unsigned char* image4 = stbi_load("cobblestone.jpg", &width, &height, &bitDepth, 0);
	if (!image4) cout << "Unable to load file!" << endl;
	
	glGenTextures(1, &cobblestoneTx);
	glBindTexture(GL_TEXTURE_2D, cobblestoneTx);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image4);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glGenerateMipmap(GL_TEXTURE_2D);
	//glBindTexture(GL_TEXTURE_2D, 0);
	stbi_image_free(image4);

	unsigned char* image5 = stbi_load("dirt.jpg", &width, &height, &bitDepth, 0);
	if (!image5) cout << "Unable to load file!" << endl;
	
	glGenTextures(1, &dirtTx);
	glBindTexture(GL_TEXTURE_2D, dirtTx);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image5);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glGenerateMipmap(GL_TEXTURE_2D);
	//glBindTexture(GL_TEXTURE_2D, 0);
	stbi_image_free(image5);

	unsigned char* image6 = stbi_load("cobblefloor.jpg", &width, &height, &bitDepth, 0);
	if (!image6) cout << "Unable to load file!" << endl;

	glGenTextures(1, &cobblefloorTx);
	glBindTexture(GL_TEXTURE_2D, cobblefloorTx);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image6);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glGenerateMipmap(GL_TEXTURE_2D);
	//glBindTexture(GL_TEXTURE_2D, 0);
	stbi_image_free(image6);

	unsigned char* image7 = stbi_load("mazedoor.jpg", &width, &height, &bitDepth, 0);
	if (!image7) cout << "Unable to load file!" << endl;

	glGenTextures(1, &doorTx);
	glBindTexture(GL_TEXTURE_2D, doorTx);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image7);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glGenerateMipmap(GL_TEXTURE_2D);
	//glBindTexture(GL_TEXTURE_2D, 0);
	stbi_image_free(image7);

	glUniform1i(glGetUniformLocation(program, "texture0"), 0);

	// Setting ambient Light.
	glUniform3f(glGetUniformLocation(program, "aLight.ambientColour"), aLight.ambientColour.x, aLight.ambientColour.y, aLight.ambientColour.z);
	glUniform1f(glGetUniformLocation(program, "aLight.ambientStrength"), aLight.ambientStrength);

	// Setting point lights
	// Tried to make this a for loop but couldn't figure it out :p
	glUniform3f(glGetUniformLocation(program, "pLights[0].base.diffuseColour"), pLights[0].diffuseColour.x, pLights[0].diffuseColour.y, pLights[0].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[0].base.diffuseStrength"), pLights[0].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[0].position"), pLights[0].position.x, pLights[0].position.y, pLights[0].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[0].constant"), pLights[0].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[0].linear"), pLights[0].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[0].exponent"), pLights[0].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[1].base.diffuseColour"), pLights[1].diffuseColour.x, pLights[1].diffuseColour.y, pLights[1].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[1].base.diffuseStrength"), pLights[1].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[1].position"), pLights[1].position.x, pLights[1].position.y, pLights[1].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[1].constant"), pLights[1].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[1].linear"), pLights[1].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[1].exponent"), pLights[1].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[2].base.diffuseColour"), pLights[2].diffuseColour.x, pLights[2].diffuseColour.y, pLights[2].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[2].base.diffuseStrength"), pLights[2].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[2].position"), pLights[2].position.x, pLights[2].position.y, pLights[2].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[2].constant"), pLights[2].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[2].linear"), pLights[2].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[2].exponent"), pLights[2].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[3].base.diffuseColour"), pLights[3].diffuseColour.x, pLights[3].diffuseColour.y, pLights[3].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[3].base.diffuseStrength"), pLights[3].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[3].position"), pLights[3].position.x, pLights[3].position.y, pLights[3].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[3].constant"), pLights[3].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[3].linear"), pLights[3].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[3].exponent"), pLights[3].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[4].base.diffuseColour"), pLights[4].diffuseColour.x, pLights[4].diffuseColour.y, pLights[4].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[4].base.diffuseStrength"), pLights[4].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[4].position"), pLights[4].position.x, pLights[4].position.y, pLights[4].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[4].constant"), pLights[4].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[4].linear"), pLights[4].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[4].exponent"), pLights[4].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[5].base.diffuseColour"), pLights[5].diffuseColour.x, pLights[5].diffuseColour.y, pLights[5].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[5].base.diffuseStrength"), pLights[5].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[5].position"), pLights[5].position.x, pLights[5].position.y, pLights[5].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[5].constant"), pLights[5].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[5].linear"), pLights[5].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[5].exponent"), pLights[5].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[6].base.diffuseColour"), pLights[6].diffuseColour.x, pLights[6].diffuseColour.y, pLights[6].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[6].base.diffuseStrength"), pLights[6].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[6].position"), pLights[6].position.x, pLights[6].position.y, pLights[6].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[6].constant"), pLights[6].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[6].linear"), pLights[6].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[6].exponent"), pLights[6].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[7].base.diffuseColour"), pLights[7].diffuseColour.x, pLights[7].diffuseColour.y, pLights[7].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[7].base.diffuseStrength"), pLights[7].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[7].position"), pLights[7].position.x, pLights[7].position.y, pLights[7].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[7].constant"), pLights[7].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[7].linear"), pLights[7].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[7].exponent"), pLights[7].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[8].base.diffuseColour"), pLights[8].diffuseColour.x, pLights[8].diffuseColour.y, pLights[8].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[8].base.diffuseStrength"), pLights[8].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[8].position"), pLights[8].position.x, pLights[8].position.y, pLights[8].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[8].constant"), pLights[8].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[8].linear"), pLights[8].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[8].exponent"), pLights[8].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[9].base.diffuseColour"), pLights[9].diffuseColour.x, pLights[9].diffuseColour.y, pLights[9].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[9].base.diffuseStrength"), pLights[9].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[9].position"), pLights[9].position.x, pLights[9].position.y, pLights[9].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[9].constant"), pLights[9].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[9].linear"), pLights[9].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[9].exponent"), pLights[9].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[10].base.diffuseColour"), pLights[10].diffuseColour.x, pLights[10].diffuseColour.y, pLights[10].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[10].base.diffuseStrength"), pLights[10].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[10].position"), pLights[10].position.x, pLights[10].position.y, pLights[10].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[10].constant"), pLights[10].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[10].linear"), pLights[10].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[10].exponent"), pLights[10].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[11].base.diffuseColour"), pLights[11].diffuseColour.x, pLights[11].diffuseColour.y, pLights[11].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[11].base.diffuseStrength"), pLights[11].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[11].position"), pLights[11].position.x, pLights[11].position.y, pLights[11].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[11].constant"), pLights[11].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[11].linear"), pLights[11].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[11].exponent"), pLights[11].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[12].base.diffuseColour"), pLights[12].diffuseColour.x, pLights[12].diffuseColour.y, pLights[12].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[12].base.diffuseStrength"), pLights[12].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[12].position"), pLights[12].position.x, pLights[12].position.y, pLights[12].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[12].constant"), pLights[12].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[12].linear"), pLights[12].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[12].exponent"), pLights[12].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[13].base.diffuseColour"), pLights[13].diffuseColour.x, pLights[13].diffuseColour.y, pLights[13].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[13].base.diffuseStrength"), pLights[13].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[13].position"), pLights[13].position.x, pLights[13].position.y, pLights[13].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[13].constant"), pLights[13].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[13].linear"), pLights[13].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[13].exponent"), pLights[13].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[14].base.diffuseColour"), pLights[14].diffuseColour.x, pLights[14].diffuseColour.y, pLights[14].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[14].base.diffuseStrength"), pLights[14].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[14].position"), pLights[14].position.x, pLights[14].position.y, pLights[14].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[14].constant"), pLights[14].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[14].linear"), pLights[14].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[14].exponent"), pLights[14].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[15].base.diffuseColour"), pLights[15].diffuseColour.x, pLights[15].diffuseColour.y, pLights[15].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[15].base.diffuseStrength"), pLights[15].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[15].position"), pLights[15].position.x, pLights[15].position.y, pLights[15].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[15].constant"), pLights[15].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[15].linear"), pLights[15].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[15].exponent"), pLights[15].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[16].base.diffuseColour"), pLights[16].diffuseColour.x, pLights[16].diffuseColour.y, pLights[16].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[16].base.diffuseStrength"), pLights[16].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[16].position"), pLights[16].position.x, pLights[16].position.y, pLights[16].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[16].constant"), pLights[16].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[16].linear"), pLights[16].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[16].exponent"), pLights[16].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[17].base.diffuseColour"), pLights[17].diffuseColour.x, pLights[17].diffuseColour.y, pLights[17].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[17].base.diffuseStrength"), pLights[17].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[17].position"), pLights[17].position.x, pLights[17].position.y, pLights[17].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[17].constant"), pLights[17].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[17].linear"), pLights[17].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[17].exponent"), pLights[17].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[18].base.diffuseColour"), pLights[18].diffuseColour.x, pLights[18].diffuseColour.y, pLights[18].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[18].base.diffuseStrength"), pLights[18].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[18].position"), pLights[18].position.x, pLights[18].position.y, pLights[18].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[18].constant"), pLights[18].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[18].linear"), pLights[18].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[18].exponent"), pLights[18].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[19].base.diffuseColour"), pLights[19].diffuseColour.x, pLights[19].diffuseColour.y, pLights[19].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[19].base.diffuseStrength"), pLights[19].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[19].position"), pLights[19].position.x, pLights[19].position.y, pLights[19].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[19].constant"), pLights[19].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[19].linear"), pLights[19].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[19].exponent"), pLights[19].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[20].base.diffuseColour"), pLights[20].diffuseColour.x, pLights[20].diffuseColour.y, pLights[20].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[20].base.diffuseStrength"), pLights[20].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[20].position"), pLights[20].position.x, pLights[20].position.y, pLights[20].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[20].constant"), pLights[20].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[20].linear"), pLights[20].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[20].exponent"), pLights[20].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[21].base.diffuseColour"), pLights[21].diffuseColour.x, pLights[21].diffuseColour.y, pLights[21].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[21].base.diffuseStrength"), pLights[21].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[21].position"), pLights[21].position.x, pLights[21].position.y, pLights[21].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[21].constant"), pLights[21].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[21].linear"), pLights[21].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[21].exponent"), pLights[21].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[22].base.diffuseColour"), pLights[22].diffuseColour.x, pLights[22].diffuseColour.y, pLights[22].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[22].base.diffuseStrength"), pLights[22].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[22].position"), pLights[22].position.x, pLights[22].position.y, pLights[22].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[22].constant"), pLights[22].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[22].linear"), pLights[22].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[22].exponent"), pLights[22].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[23].base.diffuseColour"), pLights[23].diffuseColour.x, pLights[23].diffuseColour.y, pLights[23].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[23].base.diffuseStrength"), pLights[23].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[23].position"), pLights[23].position.x, pLights[23].position.y, pLights[23].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[23].constant"), pLights[23].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[23].linear"), pLights[23].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[23].exponent"), pLights[23].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[24].base.diffuseColour"), pLights[24].diffuseColour.x, pLights[24].diffuseColour.y, pLights[24].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[24].base.diffuseStrength"), pLights[24].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[24].position"), pLights[24].position.x, pLights[24].position.y, pLights[24].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[24].constant"), pLights[24].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[24].linear"), pLights[24].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[24].exponent"), pLights[24].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[25].base.diffuseColour"), pLights[25].diffuseColour.x, pLights[25].diffuseColour.y, pLights[25].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[25].base.diffuseStrength"), pLights[25].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[25].position"), pLights[25].position.x, pLights[25].position.y, pLights[25].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[25].constant"), pLights[25].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[25].linear"), pLights[25].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[25].exponent"), pLights[25].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[26].base.diffuseColour"), pLights[26].diffuseColour.x, pLights[26].diffuseColour.y, pLights[26].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[26].base.diffuseStrength"), pLights[26].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[26].position"), pLights[26].position.x, pLights[26].position.y, pLights[26].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[26].constant"), pLights[26].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[26].linear"), pLights[26].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[26].exponent"), pLights[26].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[27].base.diffuseColour"), pLights[27].diffuseColour.x, pLights[27].diffuseColour.y, pLights[27].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[27].base.diffuseStrength"), pLights[27].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[27].position"), pLights[27].position.x, pLights[27].position.y, pLights[27].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[27].constant"), pLights[27].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[27].linear"), pLights[27].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[27].exponent"), pLights[27].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[28].base.diffuseColour"), pLights[28].diffuseColour.x, pLights[28].diffuseColour.y, pLights[28].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[28].base.diffuseStrength"), pLights[28].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[28].position"), pLights[28].position.x, pLights[28].position.y, pLights[28].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[28].constant"), pLights[28].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[28].linear"), pLights[28].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[28].exponent"), pLights[28].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[29].base.diffuseColour"), pLights[29].diffuseColour.x, pLights[29].diffuseColour.y, pLights[29].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[29].base.diffuseStrength"), pLights[29].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[29].position"), pLights[29].position.x, pLights[29].position.y, pLights[29].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[29].constant"), pLights[29].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[29].linear"), pLights[29].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[29].exponent"), pLights[29].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[30].base.diffuseColour"), pLights[30].diffuseColour.x, pLights[30].diffuseColour.y, pLights[30].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[30].base.diffuseStrength"), pLights[30].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[30].position"), pLights[30].position.x, pLights[30].position.y, pLights[30].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[30].constant"), pLights[30].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[30].linear"), pLights[30].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[30].exponent"), pLights[30].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[31].base.diffuseColour"), pLights[31].diffuseColour.x, pLights[31].diffuseColour.y, pLights[31].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[31].base.diffuseStrength"), pLights[31].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[31].position"), pLights[31].position.x, pLights[31].position.y, pLights[31].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[31].constant"), pLights[31].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[31].linear"), pLights[31].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[31].exponent"), pLights[31].exponent);

	glUniform3f(glGetUniformLocation(program, "pLights[32].base.diffuseColour"), pLights[32].diffuseColour.x, pLights[32].diffuseColour.y, pLights[32].diffuseColour.z);
	glUniform1f(glGetUniformLocation(program, "pLights[32].base.diffuseStrength"), pLights[32].diffuseStrength);
	glUniform3f(glGetUniformLocation(program, "pLights[32].position"), pLights[32].position.x, pLights[32].position.y, pLights[32].position.z);
	glUniform1f(glGetUniformLocation(program, "pLights[32].constant"), pLights[32].constant);
	glUniform1f(glGetUniformLocation(program, "pLights[32].linear"), pLights[32].linear);
	glUniform1f(glGetUniformLocation(program, "pLights[32].exponent"), pLights[32].exponent);


	vao = 0;
	glGenVertexArrays(1, &vao);
	glBindVertexArray(vao);

		ibo = 0;
		glGenBuffers(1, &ibo);
	
		points_vbo = 0;
		glGenBuffers(1, &points_vbo);

		colors_vbo = 0;
		glGenBuffers(1, &colors_vbo);

		uv_vbo = 0;
		glGenBuffers(1, &uv_vbo);

		normals_vbo = 0;
		glGenBuffers(1, &normals_vbo);

	glBindVertexArray(0); // Can optionally unbind the vertex array to avoid modification.

	// Change shape data.
	//g_prism.SetMat(0.1, 16);
	g_grid.SetMat(0.0, 16);

	// Enable depth test and blend.
	glEnable(GL_DEPTH_TEST);
	//glDisable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	//glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	
	// Enable smoothing.
	glEnable(GL_LINE_SMOOTH);
	glEnable(GL_POLYGON_SMOOTH);
	// Enable face culling.
	//glEnable(GL_CULL_FACE);
	//glFrontFace(GL_CCW);
	//glCullFace(GL_BACK);

	// Final init function: populate the maze vector
	populateVectors(11, 3, 11, 3, 4.0f, 36.0f);
	populateVectors(3, 1, 3, 1, 15.0f, 36.0f);
	populateVectors(1, 2, 1, 2, 18.0f, 36.0f);
	populateVectors(4, 2, 4, 2, 22.0f, 36.0f);
	populateVectors(1, 30, 1, 30, 25.0f, 34.0f);
	populateVectors(2, 9, 2, 9, 4.0f, 33.0f);
	populateVectors(4, 2, 4, 2, 9.0f, 32.0f);
	populateVectors(1, 2, 1, 2, 12.0f, 35.0f);
	populateVectors(3, 3, 3, 3, 16.0f, 34.0f);
	populateVectors(1, 2, 1, 2, 14.0f, 33.0f);
	populateVectors(3, 3, 3, 3, 6.0f, 27.0f);
	populateVectors(1, 2, 1, 2, 8.0f, 24.0f);
	populateVectors(1, 4, 1, 4, 9.0f, 29.0f);
	populateVectors(1, 4, 1, 4, 7.0f, 32.0f);
	populateVectors(4, 1, 4, 1, 11.0f, 30.0f);
	populateVectors(2, 3, 2, 3, 15.0f, 30.0f);
	populateVectors(3, 1, 3, 1, 11.0f, 28.0f);
	populateVectors(9, 1, 9, 1, 10.0f, 26.0f);
	populateVectors(1, 4, 1, 4, 18.0f, 31.0f);
	populateVectors(1, 20, 1, 20, 4.0f, 25.0f);
	populateVectors(19, 1, 19, 1, 7.0f, 5.0f);
	populateVectors(4, 2, 4, 2, 9.0f, 7.0f);
	populateVectors(2, 1, 2, 1, 13.0f, 7.0f);
	populateVectors(2, 2, 2, 2, 16.0f, 7.0f);
	populateVectors(3, 2, 3, 2, 22.0f, 7.0f);
	populateVectors(3, 1, 3, 1, 19.0f, 8.0f);
	populateVectors(1, 1, 1, 1, 19.0f, 7.0f);
	populateVectors(1, 1, 1, 1, 21.0f, 7.0f);
	populateVectors(2, 1, 2, 1, 6.0f, 7.0f);
	populateVectors(5, 1, 5, 1, 5.0f, 9.0f);
	populateVectors(1, 3, 1, 3, 9.0f, 12.0f);
	populateVectors(3, 1, 3, 1, 6.0f, 12.0f);
	populateVectors(1, 1, 1, 1, 6.0f, 11.0f);
	populateVectors(2, 6, 2, 6, 5.0f, 19.0f);
	populateVectors(1, 3, 1, 3, 6.0f, 23.0f);
	populateVectors(3, 3, 3, 3, 7.0f, 16.0f);
	populateVectors(5, 1, 5, 1, 10.0f, 16.0f);
	populateVectors(2, 1, 2, 1, 16.0f, 16.0f);
	populateVectors(6, 1, 6, 1, 19.0f, 16.0f);
	populateVectors(1, 2, 1, 2, 24.0f, 18.0f);
	populateVectors(1, 6, 1, 6, 11.0f, 14.0f);
	populateVectors(3, 1, 3, 1, 12.0f, 9.0f);
	populateVectors(1, 4, 1, 4, 14.0f, 13.0f);
	populateVectors(1, 1, 1, 1, 12.0f, 12.0f);
	populateVectors(6, 1, 6, 1, 13.0f, 14.0f);
	populateVectors(2, 2, 2, 2, 19.0f, 14.0f);
	populateVectors(2, 2, 2, 2, 22.0f, 14.0f);
	populateVectors(1, 1, 1, 1, 22.0f, 12.0f);
	populateVectors(2, 4, 2, 4, 16.0f, 12.0f);
	populateVectors(7, 1, 7, 1, 18.0f, 11.0f);
	populateVectors(4, 1, 4, 1, 18.0f, 10.0f);
	populateVectors(1, 4, 1, 4, 8.0f, 21.0f);
	populateVectors(1, 4, 1, 4, 18.0f, 21.0f);
	populateVectors(9, 1, 9, 1, 9.0f, 18.0f);
	populateVectors(3, 1, 3, 1, 20.0f, 18.0f);
	populateVectors(1, 4, 1, 4, 22.0f, 22.0f);
	populateVectors(2, 2, 2, 2, 20.0f, 21.0f);
	populateVectors(1, 1, 1, 1, 23.0f, 20.0f);
	populateVectors(1, 3, 1, 3, 18.0f, 25.0f);
	populateVectors(2, 1, 2, 1, 19.0f, 23.0f);
	populateVectors(2, 1, 2, 1, 22.0f, 24.0f);
	populateVectors(1, 3, 1, 3, 24.0f, 24.0f);
	populateVectors(1, 3, 1, 3, 20.0f, 27.0f);
	populateVectors(2, 1, 2, 1, 20.0f, 29.0f);
	populateVectors(1, 5, 1, 5, 22.0f, 30.0f);
	populateVectors(1, 1, 1, 1, 23.0f, 26.0f);
	populateVectors(1, 1, 1, 1, 23.0f, 30.0f);
	populateVectors(1, 1, 1, 1, 24.0f, 28.0f);
	populateVectors(1, 2, 1, 2, 24.0f, 31.0f);
	populateVectors(2, 2, 2, 2, 19.0f, 32.0f);
	populateVectors(2, 1, 2, 1, 21.0f, 32.0f);
	populateVectors(2, 1, 2, 1, 22.0f, 33.0f);
	// Maze has been made

	timer(0); 
}


//---------------------------------------------------------------------
//
// calculateView
//
void calculateView()
{
	frontVec.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
	frontVec.y = sin(glm::radians(pitch));
	frontVec.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
	frontVec = glm::normalize(frontVec);
	rightVec = glm::normalize(glm::cross(frontVec, worldUp));
	upVec = glm::normalize(glm::cross(rightVec, frontVec));

	View = glm::lookAt(
		position, // Camera position
		position + frontVec, // Look target
		upVec); // Up vector
	glUniform3f(glGetUniformLocation(program, "eyePosition"), position.x, position.y, position.z);
}

//---------------------------------------------------------------------
//
// transformModel
//
void transformObject(glm::vec3 scale, glm::vec3 rotationAxis, float rotationAngle, glm::vec3 translation) {
	glm::mat4 Model;
	Model = glm::mat4(1.0f);
	Model = glm::translate(Model, translation);
	Model = glm::rotate(Model, glm::radians(rotationAngle), rotationAxis);
	Model = glm::scale(Model, scale);
	
	calculateView();
	glUniformMatrix4fv(modelID, 1, GL_FALSE, &Model[0][0]);
	glUniformMatrix4fv(viewID, 1, GL_FALSE, &View[0][0]);
	glUniformMatrix4fv(projID, 1, GL_FALSE, &Projection[0][0]);
}

// Vector filling function
void populateVectors(int width, int length, int wScale, int lScale, float xLoc, float zLoc)
{
	hedgeVec.emplace_back(RectPrism(width, length, wScale, lScale));
	pointsVec.push_back(xLoc);
	pointsVec.push_back(zLoc);
}

// Maze drawing function
void drawMaze()
{
	for (int i = 0; i < hedgeVec.size(); i++)
	{
		glBindTexture(GL_TEXTURE_2D, hedgeTx);
		hedgeVec.at(i).BufferShape(&ibo, &points_vbo, &colors_vbo, &uv_vbo, &normals_vbo, program);
		transformObject(glm::vec3(1.0f, 1.0f, 1.0f), X_AXIS, 0.0f, glm::vec3(pointsVec.at(2 * i), 0.0f, -1 * pointsVec.at((2 * i) + 1)));
		glDrawElements(GL_TRIANGLES, g_cube.NumIndices(), GL_UNSIGNED_SHORT, 0);
	}
}

//---------------------------------------------------------------------
//
// display
//
void display(void)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Bonus check
	glm::vec3 vectorToExit = position - glm::vec3(5.5f, 0.0f, -4.5f);
	float distToExit = glm::length(vectorToExit);
	if (distToExit < 1.75f)
	{
		if (!keyCollected)
		{
			cout << "You try to open the exit gate. It seems to be locked, as it doesn't open" << endl;
		}
		else if (!keyPlaced)
		{
			cout << "You try to place the cube into the gate, but notice there are no holes. Maybe it goes somewhere else?" << endl;
		}
		else if (!winText)
		{
			cout << "You open the gate and exit the hedge maze." << endl << endl;
			cout << "Congratulations, you win!" << endl;
			winText = true;
		}
	}
	if (!keyCollected)
	{
		glm::vec3 vectorToKey = position - glm::vec3(23.375f, 0.25f, -8.625f);
		float distToKey = glm::length(vectorToKey);
		if (distToKey <= 0.75f)
		{
			cout << "You found a cube-shaped key!" << endl;
			keyCollected = true;
		}
	}
	if (!keyPlaced)
	{
		glm::vec3 vectorToPedestal = position - glm::vec3(13.5f, 0.6f, -21.5f);
		float distToPedestal = glm::length(vectorToPedestal);
		if (distToPedestal < 1.0f)
		{
			if (!keyCollected)
			{
				cout << "There's a pedestal here, maybe something goes into it?" << endl;
			}
			else
			{
				cout << "You place the key into the pedestal. It begins to float, and you hear a click in the distance." << endl;
				keyPlaced = true;
			}
		}
	}

	glBindVertexArray(vao);
	// Draw all shapes.

	//glEnable(GL_DEPTH_TEST);

	// Ground
	glBindTexture(GL_TEXTURE_2D, dirtTx);
	g_grid.BufferShape(&ibo, &points_vbo, &colors_vbo, &uv_vbo, &normals_vbo, program);
	transformObject(glm::vec3(1.0f, 1.0f, 1.0f), X_AXIS, -90.0f, glm::vec3(0.0f, 0.0f, 0.0f));
	glDrawElements(GL_TRIANGLES, g_grid.NumIndices(), GL_UNSIGNED_SHORT, 0);

	// Render middle room
	glBindTexture(GL_TEXTURE_2D, cobblefloorTx);
	g_roomFloor.BufferShape(&ibo, &points_vbo, &colors_vbo, &uv_vbo, &normals_vbo, program);
	transformObject(glm::vec3(0.99f, 1.0f, 1.0f), X_AXIS, 0.0f, glm::vec3(8.05f, -0.9f, -25.0f));
	glDrawElements(GL_TRIANGLES, g_cube.NumIndices(), GL_UNSIGNED_SHORT, 0);

	glBindTexture(GL_TEXTURE_2D, cobblestoneTx);
	g_roomWall_1.BufferShape(&ibo, &points_vbo, &colors_vbo, &uv_vbo, &normals_vbo, program);
	transformObject(glm::vec3(1.0f, 1.0f, 1.0f), X_AXIS, 0.0f, glm::vec3(9.0f, 0.0f, -25.0f));
	glDrawElements(GL_TRIANGLES, g_cube.NumIndices(), GL_UNSIGNED_SHORT, 0);

	glBindTexture(GL_TEXTURE_2D, cobblestoneTx);
	g_roomWall_2.BufferShape(&ibo, &points_vbo, &colors_vbo, &uv_vbo, &normals_vbo, program);
	transformObject(glm::vec3(1.0f, 1.0f, 1.0f), X_AXIS, 0.0f, glm::vec3(9.0f, 0.0f, -21.0f));
	glDrawElements(GL_TRIANGLES, g_cube.NumIndices(), GL_UNSIGNED_SHORT, 0);

	glBindTexture(GL_TEXTURE_2D, cobblestoneTx);
	g_roomWall_3.BufferShape(&ibo, &points_vbo, &colors_vbo, &uv_vbo, &normals_vbo, program);
	transformObject(glm::vec3(1.0f, 1.0f, 1.0f), X_AXIS, 0.0f, glm::vec3(17.0f, 0.0f, -25.0f));
	glDrawElements(GL_TRIANGLES, g_cube.NumIndices(), GL_UNSIGNED_SHORT, 0);

	glBindTexture(GL_TEXTURE_2D, cobblestoneTx);
	g_roomWall_4.BufferShape(&ibo, &points_vbo, &colors_vbo, &uv_vbo, &normals_vbo, program);
	transformObject(glm::vec3(1.0f, 1.0f, 1.0f), X_AXIS, 0.0f, glm::vec3(17.0f, 0.0f, -21.0f));
	glDrawElements(GL_TRIANGLES, g_cube.NumIndices(), GL_UNSIGNED_SHORT, 0);

	glBindTexture(GL_TEXTURE_2D, cobblestoneTx);
	g_roomWall_5.BufferShape(&ibo, &points_vbo, &colors_vbo, &uv_vbo, &normals_vbo, program);
	transformObject(glm::vec3(1.0f, 1.0f, 1.0f), X_AXIS, 0.0f, glm::vec3(10.0f, 0.0f, -25.0f));
	glDrawElements(GL_TRIANGLES, g_cube.NumIndices(), GL_UNSIGNED_SHORT, 0);

	glBindTexture(GL_TEXTURE_2D, cobblestoneTx);
	g_roomWall_6.BufferShape(&ibo, &points_vbo, &colors_vbo, &uv_vbo, &normals_vbo, program);
	transformObject(glm::vec3(1.0f, 1.0f, 1.0f), X_AXIS, 0.0f, glm::vec3(10.0f, 0.0f, -19.0f));
	glDrawElements(GL_TRIANGLES, g_cube.NumIndices(), GL_UNSIGNED_SHORT, 0);

	// Maze gates
	glBindTexture(GL_TEXTURE_2D, doorTx);
	g_gate_1.BufferShape(&ibo, &points_vbo, &colors_vbo, &uv_vbo, &normals_vbo, program);
	transformObject(glm::vec3(1.0f, 1.0f, 1.0f), X_AXIS, 0.0f, glm::vec3(20.0f, 0.0f, -36.0f));
	glDrawElements(GL_TRIANGLES, g_cube.NumIndices(), GL_UNSIGNED_SHORT, 0);

	glBindTexture(GL_TEXTURE_2D, cobblestoneTx);
	g_gatewall_1.BufferShape(&ibo, &points_vbo, &colors_vbo, &uv_vbo, &normals_vbo, program);
	transformObject(glm::vec3(1.0f, 1.0f, 1.0f), X_AXIS, 0.0f, glm::vec3(21.0f, 0.0f, -36.0f));
	glDrawElements(GL_TRIANGLES, g_cube.NumIndices(), GL_UNSIGNED_SHORT, 0);

	glBindTexture(GL_TEXTURE_2D, cobblestoneTx);
	g_gatewall_2.BufferShape(&ibo, &points_vbo, &colors_vbo, &uv_vbo, &normals_vbo, program);
	transformObject(glm::vec3(1.0f, 1.0f, 1.0f), X_AXIS, 0.0f, glm::vec3(19.0f, 0.0f, -36.0f));
	glDrawElements(GL_TRIANGLES, g_cube.NumIndices(), GL_UNSIGNED_SHORT, 0);

	glBindTexture(GL_TEXTURE_2D, doorTx);
	g_gate_2.BufferShape(&ibo, &points_vbo, &colors_vbo, &uv_vbo, &normals_vbo, program);
	transformObject(glm::vec3(1.0f, 1.0f, 1.0f), X_AXIS, 0.0f, glm::vec3(5.0f, 0.0f, -5.0f));
	glDrawElements(GL_TRIANGLES, g_cube.NumIndices(), GL_UNSIGNED_SHORT, 0);

	glBindTexture(GL_TEXTURE_2D, cobblestoneTx);
	g_gatewall_3.BufferShape(&ibo, &points_vbo, &colors_vbo, &uv_vbo, &normals_vbo, program);
	transformObject(glm::vec3(1.0f, 1.0f, 1.0f), X_AXIS, 0.0f, glm::vec3(4.0f, 0.0f, -5.0f));
	glDrawElements(GL_TRIANGLES, g_cube.NumIndices(), GL_UNSIGNED_SHORT, 0);

	glBindTexture(GL_TEXTURE_2D, cobblestoneTx);
	g_gatewall_4.BufferShape(&ibo, &points_vbo, &colors_vbo, &uv_vbo, &normals_vbo, program);
	transformObject(glm::vec3(1.0f, 1.0f, 1.0f), X_AXIS, 0.0f, glm::vec3(6.0f, 0.0f, -5.0f));
	glDrawElements(GL_TRIANGLES, g_cube.NumIndices(), GL_UNSIGNED_SHORT, 0);

	drawMaze();

	// Bonus pedestal and "key"
	if (!keyCollected)
	{
		glBindTexture(GL_TEXTURE_2D, alexTx);
		g_cube.BufferShape(&ibo, &points_vbo, &colors_vbo, &uv_vbo, &normals_vbo, program);
		transformObject(glm::vec3(0.25f, 0.25f, 0.25f), X_AXIS, 0.0f, glm::vec3(23.375f, 0.25f, -8.625f));
		glDrawElements(GL_TRIANGLES, g_cube.NumIndices(), GL_UNSIGNED_SHORT, 0);
	}

	if (keyPlaced)
	{
		glBindTexture(GL_TEXTURE_2D, alexTx);
		g_cube.BufferShape(&ibo, &points_vbo, &colors_vbo, &uv_vbo, &normals_vbo, program);
		transformObject(glm::vec3(0.25f, 0.25f, 0.25f), Y_AXIS, keyAngle+=1.0f, glm::vec3(13.5f, keyHeight, -21.5f));
		glDrawElements(GL_TRIANGLES, g_cube.NumIndices(), GL_UNSIGNED_SHORT, 0);

		// Make key float
		if (movingUp)
		{
			keyHeight += 0.005f;
			if (keyHeight >= 0.7f)
			{
				movingUp = false;
			}
		}
		else
		{
			keyHeight -= 0.005f;
			if (keyHeight <= 0.5f)
			{
				movingUp = true;
			}
		}
	}

	glBindTexture(GL_TEXTURE_2D, blankTx);
	g_pedestal.BufferShape(&ibo, &points_vbo, &colors_vbo, &uv_vbo, &normals_vbo, program);
	transformObject(glm::vec3(0.5f, 0.35f, 0.5f), X_AXIS, 0.0f, glm::vec3(13.25f, 0.0f, -21.75f));
	glDrawElements(GL_TRIANGLES, g_pedestal.NumIndices(), GL_UNSIGNED_SHORT, 0);
	
	glBindVertexArray(0); // Done writing.
	glutSwapBuffers(); // Now for a potentially smoother render.
}

void parseKeys()
{
	if (keys & KEY_FORWARD)
		position += frontVec * MOVESPEED;
	else if (keys & KEY_BACKWARD)
		position -= frontVec * MOVESPEED;
	if (keys & KEY_LEFT)
		position -= rightVec * MOVESPEED;
	else if (keys & KEY_RIGHT)
		position += rightVec * MOVESPEED;
	if (keys & KEY_UP)
		position.y += MOVESPEED;
	else if (keys & KEY_DOWN)
		position.y -= MOVESPEED;
}

void timer(int) { // essentially our update()
	parseKeys();
	glutPostRedisplay();
	glutTimerFunc(1000/FPS, timer, 0); // 60 FPS or 16.67ms.
}

//---------------------------------------------------------------------
//
// keyDown
//
void keyDown(unsigned char key, int x, int y) // x and y is mouse location upon key press.
{
	switch (key)
	{
	case 'w':
		if (!(keys & KEY_FORWARD))
			keys |= KEY_FORWARD; break;
	case 's':
		if (!(keys & KEY_BACKWARD))
			keys |= KEY_BACKWARD; break;
	case 'a':
		if (!(keys & KEY_LEFT))
			keys |= KEY_LEFT; break;
	case 'd':
		if (!(keys & KEY_RIGHT))
			keys |= KEY_RIGHT; break;
	case 'r':
		if (!(keys & KEY_UP))
			keys |= KEY_UP; break;
	case 'f':
		if (!(keys & KEY_DOWN))
			keys |= KEY_DOWN; break;
	}
}

void keyDownSpec(int key, int x, int y) // x and y is mouse location upon key press.
{
	if (key == GLUT_KEY_UP)
	{
		if (!(keys & KEY_FORWARD))
			keys |= KEY_FORWARD;
	}
	else if (key == GLUT_KEY_DOWN)
	{
		if (!(keys & KEY_BACKWARD))
			keys |= KEY_BACKWARD;
	}
}

void keyUp(unsigned char key, int x, int y) // x and y is mouse location upon key press.
{
	switch (key)
	{
	case 'w':
		keys &= ~KEY_FORWARD; break;
	case 's':
		keys &= ~KEY_BACKWARD; break;
	case 'a':
		keys &= ~KEY_LEFT; break;
	case 'd':
		keys &= ~KEY_RIGHT; break;
	case 'r':
		keys &= ~KEY_UP; break;
	case 'f':
		keys &= ~KEY_DOWN; break;
	case ' ':
		resetView();
	}
}

void keyUpSpec(int key, int x, int y) // x and y is mouse location upon key press.
{
	if (key == GLUT_KEY_UP)
	{
		keys &= ~KEY_FORWARD;
	}
	else if (key == GLUT_KEY_DOWN)
	{
		keys &= ~KEY_BACKWARD;
	}
}

void mouseMove(int x, int y)
{
	if (keys & KEY_MOUSECLICKED)
	{
		pitch += (GLfloat)((y - lastY) * TURNSPEED);
		yaw -= (GLfloat)((x - lastX) * TURNSPEED);
		lastY = y;
		lastX = x;
	}
}

void mouseClick(int btn, int state, int x, int y)
{
	if (state == 0)
	{
		lastX = x;
		lastY = y;
		keys |= KEY_MOUSECLICKED; // Flip flag to true
		glutSetCursor(GLUT_CURSOR_NONE);
		//cout << "Mouse clicked." << endl;
	}
	else
	{
		keys &= ~KEY_MOUSECLICKED; // Reset flag to false
		glutSetCursor(GLUT_CURSOR_INHERIT);
		//cout << "Mouse released." << endl;
	}
}

void clean()
{
	cout << "Cleaning up!" << endl;
	glDeleteTextures(1, &alexTx);
	glDeleteTextures(1, &hedgeTx);
	glDeleteTextures(1, &blankTx);
	glDeleteTextures(1, &cobblestoneTx);
	glDeleteTextures(1, &dirtTx);
	glDeleteTextures(1, &cobblefloorTx);
	glDeleteTextures(1, &doorTx);
}

//---------------------------------------------------------------------
//
// main
//
int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA | GLUT_MULTISAMPLE);
	glutSetOption(GLUT_MULTISAMPLE, 8);
	glutInitWindowSize(800, 600);
	glutCreateWindow("GAME2012_Final_Holloway_Folgier");

	glewInit();	//Initializes the glew and prepares the drawing pipeline.
	init();

	glutDisplayFunc(display);
	glutKeyboardFunc(keyDown);
	glutSpecialFunc(keyDownSpec);
	glutKeyboardUpFunc(keyUp); // New function for third example.
	glutSpecialUpFunc(keyUpSpec);

	glutMouseFunc(mouseClick);
	glutMotionFunc(mouseMove); // Requires click to register.
	
	atexit(clean); // This GLUT function calls specified function before terminating program. Useful!

	glutMainLoop();

	return 0;
}
